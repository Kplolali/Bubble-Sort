#include<iostream>

//10661022
using namespace std;
int main ()
{
   int a, b,temp;
   int array[12] = {3,5,27,0,42,253,123,14,101,22,45,12};  
   cout <<"Input list ...\n";
   for(a = 0; a<10; a++) {
      cout <<array[a]<<"\t";
   }
cout<<endl;
for(a = 0; a<10; a++) {
   for(b = b+1; b<10; b++)
   {
      if(array[b] < array[a]) {
         temp = array[a];
         array[a] = array[b];
         array[b] = temp;
      }
   }
;
}
cout <<"Sorted Element List ...\n";
for(a = 0; a<10; a++) {
   cout <<array[a]<<"\t";
}
return 0;
}

